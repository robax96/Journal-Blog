
const express = require('express')
const session = require('express-session')
const bcrypt = require('bcrypt');
const saltRounds = 10;
var fs = require('fs')
const pool = require('../conn_db')
const router = express.Router()



router.get('/home', (req, res)=>{
    
    
    if(!req.session.userid){

        //STORES LOGS OF GUEST
        var dateObj = new Date();
        var log_data = '\nACCOUNT: GUEST ---' + 'Date: ' + String(dateObj) + ' -----FROM: ' + String(req.ip)
        fs.appendFileSync('/home/M00796423Rober/public_html/coursework2/logs.txt',log_data);

        //rendering of public articles
        pool.getConnection((err, connection)=>{
            if(err) throw err;
            console.log('get public posts')
            connection.query("SELECT * FROM Article WHERE content_type='public'", (err, rows)=>{
                connection.release() 
    
                if(!err){
                    res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/homepage.ejs', { title: 'Homepage', userData: rows});
                }else{
                    console.log(err)
                }
            })
        })
    }else{
        
        //create log for logged user
        if(!req.session.member_track){
            req.session.member_track = req.ip
        }

        //rendering of public, members and private (for that user) articles
        pool.getConnection((err, connection)=>{
            if(err) throw err;
            console.log('get public, members and user posts')
            connection.query("SELECT * FROM Article WHERE content_type='public' OR content_type='members' OR account_id='"+req.session.userid+"'", (err, rows)=>{
                connection.release() 

                if(!err){
                    res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/homepage.ejs', { title: 'Homepage', userData: rows});
                }else{
                    console.log(err)
                }
            })
        })
    }
})




router.get('/add_post', (req, res)=>{
    if(!req.session.userid){
        res.redirect('/home')
    }else{

        //add route to log
        req.session.member_track += ' /add_post'
        res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/add_blog.ejs')
    }
})

router.post('/add_post', (req, res)=>{

//creates date field for post object
var dateObj = new Date();
var month = dateObj.getMonth()+1;
var day = dateObj.getUTCDate();
var year = dateObj.getUTCFullYear();

var hours = dateObj.getHours();
var minutes = dateObj.getMinutes();
var seconds = dateObj.getSeconds();

//date to add to sql
var newdate = day + '/' + month + '/' + year + '--'+ hours + ':' + minutes + ':' + seconds;

//date to add to filename (tricky one :) )
var date_file_name = day + '_' + month + '_' + year + '_'+ hours + '_' + minutes + '_' + seconds;

//checks if file has been uploaded
if(!req.files || Object.keys(req.files)===0){
    var filename= 'NULL'
}
else{
    var file = req.files.a_file
    var filename = req.session.userid+date_file_name+file.name
}
    

    
    //query to create new article to db
    pool.getConnection((err, connection)=>{
        if(err) throw err;
        console.log('db connected')

        //connection.query("INSERT INTO Article(account_id,content_type,Date,Title,Content,file_name) VALUES('"+req.session.userid+"','"+req.body.a_con_type+"','"+newdate+"',"+req.body.a_title+"','"+req.body.a_content+"','"+filename+"')", (err, rows)=>{
        
        connection.query("INSERT INTO Article(account_id,content_type,Date,Title,Content,file_name) VALUES(?,?,?,?,?,?)", [req.session.userid,req.body.a_con_type,newdate,req.body.a_title,req.body.a_content,filename], (err, rows)=>{
            connection.release()

            if(!err){
                console.log('Line added')
                res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/file_added.ejs', {con_type: req.body.a_con_type, title: req.body.a_title, content: req.body.a_content, file: filename})
                
                //upload file
                if(req.files){
                    console.log(filename)
                    file.mv('/home/M00796423Rober/public_html/coursework2/public/'+filename, function(err){
                        if(err){
                            res.send(err)
                        }
                       
                    })
                      
                    
                }
                
                
            }else{ 
                console.log(err)
                res.json(err)
            }
        })

    })

})

router.get('/mod_post/:post_id', (req, res)=>{
    

    if(req.session.userid){
        //gets article data based on id and send them to ejs file for editing
        pool.getConnection((err, connection)=>{
            if(err) throw err;
            console.log('Check user permission...')
            connection.query("SELECT * FROM Article WHERE account_id='"+Number(req.session.userid)+"' AND article_id='"+Number(req.params.post_id)+"'", (err, rows)=>{
                connection.release() 

                if(!err){
                    //checks if user is allowed to modify that post
                    if(rows.length===0 && !req.session.admin){
                        res.redirect('/home')
                    }
                    else{

                        //add mod_post route to log
                        req.session.member_track += ' /mod_post'
                        req.session.member_track += req.params.post_id

                        var postid  = req.params.post_id
        
                        pool.getConnection((err, connection)=>{
                            if(err) throw err;
                            console.log('User authorized!')
                            connection.query("SELECT * FROM Article WHERE article_id='"+postid+"'", (err, rows)=>{
                                connection.release()
                                for(let i=0;i<rows.length;i++){
                                    var post_title = rows[i].Title
                                    var post_content = rows[i].Content
                                    var post_date = rows[i].Date
                                    var post_type = rows[i].content_type
                                    var file_n = rows[i].file_name
                                    req.session.blog_ttl = post_title
                                    req.session.blog_cnt = post_content
                                    req.session.blog_tp = post_type
                                    req.session.blog_nm = file_n
                                }
                
                
                                if(!err){
                                    res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/mod_post.ejs', {artic_id: postid, title: post_title, content: post_content, type: post_type, date: post_date, filename: file_n})
                                }
                                else{
                                    console.log(err)
                                }
                            })
                        })



                    }



                }else{
                    console.log(err)
                }
            })
        })
    }
    
    else{
        res.redirect('/home')
    }
        
        
        
    
})

router.post('/mod_post/:artic_id', (req, res)=>{

    //checks if post has been modified
    if(req.session.blog_cnt===req.body.ed_content && req.session.blog_tp===req.body.ed_con_type && req.session.blog_ttl===req.body.ed_title && !req.files){
        res.send('<h1>NO CHANGES WERE MADE!!!</h1><a href="/home">Homepage</a>')
    }
    else{
        //query to update post
        pool.getConnection((err, connection)=>{
            if(err) throw err;
            console.log('Update post')

            //query based on file uploaded or not
            if(req.files){
                if(req.session.blog_nm==='NULL'){
                    //creates date field for post object
                    var dateObj = new Date();
                    var month = dateObj.getMonth()+1;
                    var day = dateObj.getUTCDate();
                    var year = dateObj.getUTCFullYear();
                    var hours = dateObj.getHours();
                    var minutes = dateObj.getMinutes();
                    var seconds = dateObj.getSeconds();

                    //date to add to filename (tricky one :) )
                    var date_file_name = day + '_' + month + '_' + year + '_'+ hours + '_' + minutes + '_' + seconds;
                    req.session.filename_mod = req.session.userid+date_file_name+req.files.ed_file.name

                    var query_mod = "UPDATE Article SET content_type=?, Title=?, Content=?, file_name=? WHERE article_id='"+req.params.artic_id+"'"
                    var query_params = [req.body.ed_con_type,req.body.ed_title,req.body.ed_content,req.session.filename_mod]
                }else{
                    var query_mod = "UPDATE Article SET content_type=?, Title=?, Content=?, file_name=? WHERE article_id='"+req.params.artic_id+"'"
                    var query_params = [req.body.ed_con_type,req.body.ed_title,req.body.ed_content,req.session.blog_nm]
                }
            }else{
                var query_mod = "UPDATE Article SET content_type=?, Title=?, Content=? WHERE article_id='"+req.params.artic_id+"'"
                var query_params = [req.body.ed_con_type,req.body.ed_title,req.body.ed_content]

            }
        
            connection.query(query_mod, query_params, (err, rows)=>{
                connection.release()

                if(!err){
                    console.log('Line updated')
                    
                    if(!req.session.filename_mod){
                        //sends to ejs for summary of updates
                        res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/file_modified.ejs', {con_type: req.body.ed_con_type, title: req.body.ed_title, content: req.body.ed_content, filenm: req.session.blog_nm})
                    }else{
                        res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/file_modified.ejs', {con_type: req.body.ed_con_type, title: req.body.ed_title, content: req.body.ed_content, filenm: req.session.filename_mod})

                    }
                    //if new file has been uploaded, it will be created or replaced
                    if(req.files){

                        if(req.session.blog_nm==='NULL'){
                            console.log(req.session.filename_mod)
                            var file = req.files.ed_file
                            
                            file.mv('/home/M00796423Rober/public_html/coursework2/public/'+req.session.filename_mod, function(err){
                                if(err){
                                    res.send(err)
                                }
                       
                            })
                        }
                        else{
                            console.log(req.session.blog_nm)
                            var file = req.files.ed_file
                            
                            file.mv('/home/M00796423Rober/public_html/coursework2/public/'+req.session.blog_nm, function(err){
                                if(err){
                                    res.send(err)
                                }
                       
                            })


                        }
                      
                    
                    }
                
                
                }else{ 
                    console.log(err)
                    res.json(err)
                }
            })

        })
        
    }
})

router.get('/delete_post/:artic_id', (req, res)=>{


    if(req.session.userid){
        
        
        pool.getConnection((err, connection)=>{
            if(err) throw err;
            console.log('Checking user permission...')
            connection.query("SELECT * FROM Article WHERE account_id='"+Number(req.session.userid)+"' AND article_id='"+Number(req.params.artic_id)+"'", (err, rows)=>{
                connection.release() 

                if(!err){
                    //checks if user is allowed to delete that post
                    if(rows.length===0 && !req.session.admin){
                        res.send('Not Allowed<br><a href="/home">Homepage</a>')
                    }
                    else{
                        //add del_post to log
                        req.session.member_track += ' /delete_post'
                        req.session.member_track += req.params.artic_id
                        
                        //query to delete row
                        pool.getConnection((err, connection)=>{
                            if(err) throw err;
                            console.log('Delete post')
                            connection.query("DELETE FROM Article WHERE article_id=?",[req.params.artic_id], (err, rows)=>{
                                connection.release() 

                                if(!err){
                                    //delete file from server, if included
                                    if(req.session.blog_nm !='NULL'){
                                        fs.unlinkSync('/home/M00796423Rober/public_html/coursework2/public/'+req.session.blog_nm)
                                    }
                                    res.redirect('/home')
                                }else{
                                    console.log(err)
                                }
                            })
                        })
                    }
                
                }
            })
        })
    }else{
        res.redirect('/home')

    }
})




router.get('/personal', (req, res)=>{
    if(!req.session.userid){
        res.redirect('/home')
    }else{

        //add personal to log
        req.session.member_track += ' /personal'

        //gets only personal articles
        pool.getConnection((err, connection)=>{
            if(err) throw err;
            console.log('Getting personal posts')
            connection.query("SELECT * FROM Article WHERE account_id='"+req.session.userid+"'", (err, rows)=>{
                connection.release() 

                if(!err){
                    res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/personal_area.ejs', { title: 'Personal', userData: rows});
                }else{
                    console.log(err)
                }
            })
        })
    }
})




router.get('/register', (req, res)=>{
    if(!req.session.userid){
        res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/register.ejs')
    }
    else{
        res.redirect('/home')
    }
})

router.post('/register', (req, res)=>{
    
    //check if email and username are already in use
    pool.getConnection((err, connection)=>{
        if(err) throw err;
        console.log('Check username and email availability...')
        connection.query("SELECT * FROM accounts WHERE username=? OR email=?", [req.body.username,req.body.email], (err, rows)=>{
            connection.release() 

            if(err){
                res.send(err)  
            }
            if(rows.length===0){
                
                //checks password requirements
                var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})")
                if(strongRegex.test(req.body.password)){
                    const salt = bcrypt.genSaltSync(saltRounds);
                    const hash_psw = bcrypt.hashSync(req.body.password, salt);
                    
                    // Store hash in password DB.
                
                    pool.getConnection((err, connection)=>{
                        if(err) throw err;
                        console.log('Creating new account...')
                        connection.query("INSERT INTO accounts(username, password, email) VALUES (?,?,?) ", [req.body.username, hash_psw, req.body.email], (err, rows)=>{
                            connection.release() 
            
                            if(!err){
                                res.send('Account Added<br><a href="/home">Homepage</a>')
                                
                            
                            
                            }else{ 
                            console.log(err)
                            }
                        })
                    })
                }else{
                    res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/register.ejs')
                }
                
            }else{
                res.send('Username and/or email already in use<br><a href="/register">GO BACK</a>')
            }
            
        })
    })
    
    
     
})

router.get('/login', (req, res)=>{
    if(!req.session.userid){
        res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/login.ejs')
    }
    else{
        res.redirect('/home')
    }
})

router.post('/login', (req, res)=>{

    //checks if user exists
    pool.getConnection((err, connection)=>{
        if(err) throw err;
        console.log('Checking username...')
        connection.query("SELECT * FROM accounts Where username = '"+req.body.username+"'", (err, rows)=>{
            connection.release() 

            if(!err){
                var i = 0
                rows.forEach(element => {
                    ++i 
                });
                if(i>0){
                    //checks if password matches
                    if(bcrypt.compareSync(req.body.password, rows[0].password)){
                        var session
                        session=req.session
                        session.username=req.body.username
                        rows.forEach(element => {
                            session.userid = element.id 
                        });
                        //res.send('Hello '+session.userid)
                        res.redirect('/home')
                    }else{
                        res.send('Wrong password used<br><a href="/login">GO BACK</a>')

                    }
                    
                }
                else{
                    res.send('No user found with this username and/or password<br><a href="/login">GO BACK</a>')
                }
                
            }else{ 
                console.log(err)
            }
        })
    })
     
})


router.get('/admin_login', (req, res)=>{
    if(!req.session.userid){
        res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/admin_login.ejs')
    }
    else{
        res.redirect('/home')
    }
})

router.post('/admin_login', (req, res)=>{
    pool.getConnection((err, connection)=>{
        if(err) throw err;
        console.log('Checking admin username...')
        connection.query("SELECT * FROM admin_account Where username = '"+req.body.username+"'", (err, rows)=>{
            connection.release() 

            if(!err){
                var i = 0
                rows.forEach(element => {
                    ++i 
                });
                if(i>0){
                    if(bcrypt.compareSync(req.body.password, rows[0].password)){
                        var session
                        session=req.session
                        session.username=req.body.username
                        session.admin = true
                        rows.forEach(element => {
                            session.userid = element.id 
                        });
                    
                        res.redirect('/home')
                    }else{
                        res.send('Wrong password used<br><a href="/admin_login">GO BACK</a>')
                    }
                    
                }
                else{
                    res.send('No admin found with this username and/or password<br><a href="/admin_login">GO BACK</a>')
                }
                
            }else{ 
                console.log(err)
            }
        })
    })
     
})

router.get('/accounts_logs', (req, res)=>{
    
    if(req.session.admin){
        //gets log lines and sends them to ejs file
        var log_array = fs.readFileSync('/home/M00796423Rober/public_html/coursework2/logs.txt').toString().split("\n");
        res.render('/home/M00796423Rober/public_html/coursework2/ejs_files/logs.ejs', {logs_lines: log_array});
    }else{
        res.redirect('/home') 
    }

})
router.get('/logout', (req, res)=>{
    

    

    if(req.session.userid){

        //STORES LOG OF MEMBERS OR ADMINS
        var dateObj = new Date();
        
        if(!req.session.admin){
            var log_data = '\nID: '+req.session.userid+' -- ACCOUNT: ' + req.session.username+' ---' + 'Date: ' + String(dateObj) + ' -----FROM: ' + String(req.session.member_track)
        }
        else{
            var log_data = '\nID: '+req.session.userid+' -- ACCOUNT: ADMIN ---' + 'Date: ' + String(dateObj) + ' -----FROM: ' + String(req.session.member_track)
        }

        fs.appendFileSync('/home/M00796423Rober/public_html/coursework2/logs.txt',log_data);
        
    }
    //destroy session
    req.session.destroy();
    res.redirect('/home')
})
module.exports = router
